package space;

import java.awt.Color;

import info.gridworld.actor.Actor;

public class SpaceShip extends Actor
{
	//the user class, a picture of Mr. Smith
	public void SpaceShip()
	{
		
	}
	//Overrides the Actor's color
	public Color getColor()
	{
		return null;
	}

}
